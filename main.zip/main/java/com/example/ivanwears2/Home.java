package com.example.ivanwears2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {
    private TextView textView;
    private ImageButton btnGoProfile;
    private Button testButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnGoProfile = findViewById(R.id.imageButton2);
        textView = findViewById(R.id.textView5); // Asegúrate de tener un TextView en el layout con este ID.
        testButton = findViewById(R.id.button3);

        // Ejecutar la tarea para obtener datos del servidor
        new FetchProductsTask().execute("http://10.0.2.2/project/database/API/productquery.php>");

        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, Register.class);
                startActivity(intent);
            }
        });

        btnGoProfile.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v){
                Intent intent = new Intent(Home.this, Profile.class);
                startActivity(intent);
            }
        });
    }


    private class FetchProductsTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                reader.close();

                result = stringBuilder.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            // Aquí puedes procesar el resultado y extraer el "name"
            String name = extractNameFromXML(result);
            textView.setText(name != null ? name : "No se encontraron productos");
        }

        private String extractNameFromXML(String xml) {
            // Extraer el primer <name> del XML
            try {
                int start = xml.indexOf("<name>") + 6;
                int end = xml.indexOf("</name>");
                if (start != -1 && end != -1) {
                    return xml.substring(start, end);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
