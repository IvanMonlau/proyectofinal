package com.example.ivanwears2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {

    private EditText editUsername, editPassword, editConfirmPassword;
    private Button btnLogin;
    private Button btnGoRegister;
    private UserValidation validator = new UserValidation(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        editUsername = findViewById(R.id.edit_username);
        editPassword = findViewById(R.id.edit_password);
        btnLogin = findViewById(R.id.btn_login);
        btnGoRegister = findViewById(R.id.btn_go_register);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputUserName = editUsername.getText().toString();
                String inputPassword = editPassword.getText().toString();

                validator.validateUser(inputUserName,inputPassword);
            }
        });

        btnGoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Login activity
                Intent intent = new Intent(login.this, Register.class);
                startActivity(intent);
            }
        });
    }
}