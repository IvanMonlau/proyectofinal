package com.example.ivanwears2;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


public class UserValidation {
    Context context;
    public UserValidation(Context context) {
        this.context = context;
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    public void validateUser(String email, String password) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String url = "http://10.0.2.2/project/database/API/uservalidation.php";
                String apiResponse = null;
                String var_id;

                try {
                    Log.d("INFO", "run: TRYING...");
                    // Crear la conexión HTTP
                    URL direction = new URL(url);
                    HttpURLConnection connection = (HttpURLConnection) direction.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);

                    // Crear los datos del formulario
                    String data = "email=" + email + "&password=" + password;

                    // Escribir los datos del formulario en la solicitud HTTP
                    OutputStream output = connection.getOutputStream();
                    byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                    output.write(bytes);
                    output.flush();
                    output.close();

                    // Leer la respuesta del servidor
                    InputStream input = connection.getInputStream();
                    BufferedReader lector = new BufferedReader(new InputStreamReader(input));
                    StringBuilder answer = new StringBuilder();
                    String line;

                    while ((line = lector.readLine()) != null) {
                        answer.append(line);
                    }

                    // Cerrar la conexión HTTP
                    input.close();
                    connection.disconnect();

                    // Procesar la respuesta del servidor
                    apiResponse = answer.toString();
                } catch (ConnectException e) {
                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast toast = Toast.makeText(UserValidation.this.context, "The database is not online", Toast.LENGTH_SHORT);
                            toast.show();
                            Log.e("INFO", "run: ", e);
                        }
                    });
                } catch (IOException e) {
                    Log.d("INFO", "run: ");
                }

                String finalResultado = apiResponse;
                Log.d("INFO", "run: " + finalResultado);

                // Usamos el handler para actualizar la UI en el hilo principal
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        onPostExecute(finalResultado);
                    }
                });
            }
        });
    }

    private void onPostExecute(String resultado) {
        if (resultado != null) {
            Document doc = stringToXML(resultado);
            NodeList itemList = (NodeList) doc.getElementsByTagName("respuesta");
            Element element = (Element) itemList.item(0);
            String var_id = element.getElementsByTagName("estado").item(0).getTextContent();
            openNewActivity(var_id);
        } else {
            Log.d("INFO", "error in request");
        }
    }

    private static Document stringToXML(String xmlString) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder ;
        try {
            builder = factory.newDocumentBuilder();
            return builder.parse(new InputSource(new StringReader(xmlString)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void openNewActivity(String var_id) {
        //Toast.makeText(context, "Password " + var_id, Toast.LENGTH_SHORT).show();
        if (var_id.contains("ok")) {
            Intent intent = new Intent(this.context,Home.class);
            this.context.startActivity(intent);
        } else {
            Log.d("INFO", "KO LOGIN");
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Error!");
            builder.setMessage("Email or password is incorrect");
            builder.setCancelable(true);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

    }
}



